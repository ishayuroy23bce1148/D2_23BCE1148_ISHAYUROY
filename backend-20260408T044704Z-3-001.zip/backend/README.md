# Smart Learning Assistant Backend

This is the backend API for the Smart Learning Assistant application.

## Features

- PDF text extraction
- OCR (Optical Character Recognition) for images
- Text-to-Speech processing
- Audio notes storage and retrieval
- File upload handling with security
- Rate limiting and CORS protection

## Setup

1. Install dependencies:
```bash
npm install
```

2. Create a `.env` file (copy from `.env.example`):
```bash
cp .env.example .env
```

3. Start the development server:
```bash
npm run dev
```

## API Endpoints

### Health Check
- `GET /api/health` - Server health status

### PDF Processing
- `POST /api/pdf/extract` - Extract text from PDF files
  - Body: `multipart/form-data` with `pdf` field
  - Response: `{ success: true, text: string, pages: number, info: object }`

### OCR Processing
- `POST /api/ocr/extract` - Extract text from images
  - Body: `multipart/form-data` with `image` field
  - Response: `{ success: true, text: string, confidence: number }`

### Text-to-Speech
- `POST /api/tts/speak` - Process TTS requests
  - Body: `{ text: string, language: string, rate: number, pitch: number, volume: number }`
  - Response: `{ success: true, text: string, ... }`

### Audio Notes
- `POST /api/notes/save` - Save audio notes
  - Body: `multipart/form-data` with `audio` field and metadata
  - Response: `{ success: true, note: object }`
- `GET /api/notes/:id` - Retrieve audio note file

## Security Features

- Helmet.js for security headers
- Rate limiting (100 requests per 15 minutes)
- File type validation
- File size limits (10MB)
- CORS protection
- Input validation

## Development

The server uses nodemon for auto-restart during development. Logs are provided via Morgan middleware.

