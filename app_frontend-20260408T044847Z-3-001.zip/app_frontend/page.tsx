"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Mic,
  MicOff,
  Camera,
  FileText,
  Volume2,
  VolumeX,
  Settings,
  HelpCircle,
  Globe,
  Contrast,
  Languages,
  Sparkles,
  Brain,
  Star,
  ArrowRight,
} from "lucide-react"
import { useTTS } from "@/hooks/use-tts"
import { useVoiceRecognition } from "@/hooks/use-voice-recognition"
import { useAudioNotes } from "@/hooks/use-audio-notes"
import { useOCR } from "@/hooks/use-ocr"
import { VoiceCommandProcessor } from "@/components/voice-command-processor"
import { OCRCamera } from "@/components/ocr-camera"
import { AudioNoteRecorder } from "@/components/audio-note-recorder"
import { PDFReader } from "@/components/pdf-reader"
import { PDFManager } from "@/components/pdf-manager"
import { usePDFStorage } from "@/hooks/use-pdf-storage"
import { SettingsPanel } from "@/components/settings-panel"
import { HelpPanel } from "@/components/help-panel"
import { LanguageSelector } from "@/components/language-selector"
import { AnimatedBackground } from "@/components/animated-background"
import { FloatingElements } from "@/components/floating-elements"
import { VoiceVisualizer } from "@/components/voice-visualizer"
import { FeatureShowcase } from "@/components/feature-showcase"
import { StatsCounter } from "@/components/stats-counter"
import { GSAPAnimations } from "@/components/gsap-animations"

const SUPPORTED_LANGUAGES = {
  "en-US": { name: "English", voice: "English" },
  "hi-IN": { name: "हिंदी", voice: "Hindi" },
  "bn-IN": { name: "বাংলা", voice: "Bengali" },
  "te-IN": { name: "తెలుగు", voice: "Telugu" },
  "ta-IN": { name: "தமிழ்", voice: "Tamil" },
  "mr-IN": { name: "मराठी", voice: "Marathi" },
  "gu-IN": { name: "ગુજરાતી", voice: "Gujarati" },
  "kn-IN": { name: "ಕನ್ನಡ", voice: "Kannada" },
  "ml-IN": { name: "മലയാളം", voice: "Malayalam" },
  "pa-IN": { name: "ਪੰਜਾਬੀ", voice: "Punjabi" },
  "ur-IN": { name: "اردو", voice: "Urdu" },
  "es-ES": { name: "Español", voice: "Spanish" },
  "fr-FR": { name: "Français", voice: "French" },
  "de-DE": { name: "Deutsch", voice: "German" },
  "ja-JP": { name: "日本語", voice: "Japanese" },
  "ko-KR": { name: "한국어", voice: "Korean" },
  "zh-CN": { name: "中文", voice: "Chinese" },
}

export default function SmartLearningAssistant() {
  const [currentView, setCurrentView] = useState<"main" | "ocr" | "notes" | "pdf" | "settings" | "help" | "language">("main")
  const [isListening, setIsListening] = useState(false)
  const [lastCommand, setLastCommand] = useState<string>("")
  const [appStatus, setAppStatus] = useState<string>("Ready")
  const [isHighContrast, setIsHighContrast] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [currentLanguage, setCurrentLanguage] = useState<string>("en-US")
  const [extractedText, setExtractedText] = useState<string>("")
  const [textSummary, setTextSummary] = useState<string>("")
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })

  const { speak, stop: stopSpeaking, isSpeaking, settings: ttsSettings, updateSettings } = useTTS()
  const { startListening, stopListening, isSupported: voiceSupported } = useVoiceRecognition()
  const { 
    notes, 
    isRecording, 
    startRecording, 
    stopRecording, 
    playNote, 
    deleteNote, 
    updateNoteTitle,
    isTranscribing,
    currentTranscript,
    transcript,
    interimTranscript
  } = useAudioNotes()
  const { processImage, isProcessing } = useOCR()
  
  // PDF storage hook
  const { 
    storedPDFs, 
    currentPDF, 
    loadPDF, 
    deletePDF, 
    updatePDF, 
    clearAllPDFs 
  } = usePDFStorage()

  const mainRef = useRef<HTMLElement>(null)
  const heroRef = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  // Mouse tracking for interactive effects
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }

    const handleUserInteraction = () => {
      // This ensures TTS works after user interaction
      console.log('User interaction detected - TTS should now work')
    }

    // Add event listeners for user interaction
    document.addEventListener('click', handleUserInteraction)
    document.addEventListener('keydown', handleUserInteraction)
    document.addEventListener('touchstart', handleUserInteraction)

    window.addEventListener("mousemove", handleMouseMove)
    
    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener('click', handleUserInteraction)
      document.removeEventListener('keydown', handleUserInteraction)
      document.removeEventListener('touchstart', handleUserInteraction)
    }
  }, [])

  // Speak directions when entering language section
  useEffect(() => {
    if (currentView === "language") {
      const directions = getLocalizedMessage("languageDirections")
      speak(directions)
    }
  }, [currentView, speak, currentLanguage])

  // Apply theme modes
  useEffect(() => {
    const root = document.documentElement
    if (isHighContrast) {
      root.classList.add("high-contrast")
    } else {
      root.classList.remove("high-contrast")
    }

    if (isDarkMode) {
      root.classList.add("dark")
    } else {
      root.classList.remove("dark")
    }
  }, [isHighContrast, isDarkMode])

  // Announce app ready state with animation
  useEffect(() => {
    const timer = setTimeout(() => {
      const welcomeMessage = getLocalizedMessage("welcome")
      speak(welcomeMessage)
      setAppStatus(getLocalizedMessage("ready"))
    }, 1500)
    return () => clearTimeout(timer)
  }, [speak, currentLanguage])

  // Add this error boundary effect at the top of the component
  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      console.error("Application error:", event.error)

      // If it's a WebAssembly error, provide user feedback
      if (event.error?.message?.includes("WebAssembly") || event.error?.message?.includes("Network error")) {
        speak("Some advanced features are loading. Basic functionality is available.")
      }
    }

    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      console.error("Unhandled promise rejection:", event.reason)

      // Prevent the error from crashing the app
      event.preventDefault()

      if (event.reason?.message?.includes("WebAssembly") || event.reason?.message?.includes("Network error")) {
        speak("Loading advanced features. Please wait or try refreshing the page.")
      }
    }

    window.addEventListener("error", handleError)
    window.addEventListener("unhandledrejection", handleUnhandledRejection)

    return () => {
      window.removeEventListener("error", handleError)
      window.removeEventListener("unhandledrejection", handleUnhandledRejection)
    }
  }, [speak])

  // Get localized messages
  const getLocalizedMessage = (key: string): string => {
    const messages: { [key: string]: { [lang: string]: string } } = {
      welcome: {
        "en-US": "Welcome to Smart Learning Assistant. Your AI-powered learning companion is ready!",
        "hi-IN": "स्मार्ट लर्निंग असिस्टेंट में आपका स्वागत है। आपका AI-संचालित शिक्षा साथी तैयार है!",
        "bn-IN": "স্মার্ট লার্নিং অ্যাসিস্ট্যান্টে স্বাগতম। আপনার AI-চালিত শিক্ষা সহায়ক প্রস্তুত!",
      },
      ready: {
        "en-US": " Ready for voice commands - Say 'help' or press H",
        "hi-IN": " वॉइस कमांड के लिए तैयार - 'हेल्प' कहें या H दबाएं",
        "bn-IN": " ভয়েস কমান্ডের জন্য প্রস্তুত - 'সাহায্য' বলুন বা H চাপুন",
      },
      languageDirections: {
        "en-US": "Language selection. Choose a language from the options below. You can also use voice commands to change languages.",
        "hi-IN": "भाषा चयन। नीचे दिए गए विकल्पों में से एक भाषा चुनें। आप भाषा बदलने के लिए आवाज़ कमांड का भी उपयोग कर सकते हैं।",
        "bn-IN": "ভাষা নির্বাচন। নীচের বিকল্পগুলি থেকে একটি ভাষা নির্বাচন করুন। আপনি ভাষা পরিবর্তনের জন্য কণ্ঠ কমান্ডও ব্যবহার করতে পারেন।",
        "te-IN": "భాషా ఎంపిక। క్రింద ఇచ్చిన ఎంపికల నుండి ఒక భాషను ఎంచుకోండి। భాషను మార్చడానికి మీరు వాయిస్ కమాండ్లను కూడా ఉపయోగించవచ్చు।",
        "ta-IN": "மொழி தேர்வு। கீழே உள்ள விருப்பங்களிலிருந்து ஒரு மொழியைத் தேர்ந்தெடுக்கவும்। மொழியை மாற்ற குரல் கட்டளைகளையும் பயன்படுத்தலாம்।",
        "es-ES": "Selección de idioma. Elige un idioma de las opciones a continuación. También puedes usar comandos de voz para cambiar idiomas.",
        "fr-FR": "Sélection de langue. Choisissez une langue parmi les options ci-dessous. Vous pouvez également utiliser des commandes vocales pour changer de langue.",
        "de-DE": "Sprachauswahl. Wählen Sie eine Sprache aus den unten stehenden Optionen. Sie können auch Sprachbefehle verwenden, um Sprachen zu wechseln.",
        "ja-JP": "言語選択。下のオプションから言語を選択してください。音声コマンドを使用して言語を変更することもできます。",
        "ko-KR": "언어 선택. 아래 옵션에서 언어를 선택하세요. 음성 명령을 사용하여 언어를 변경할 수도 있습니다.",
        "zh-CN": "语言选择。从下面的选项中选择一种语言。您也可以使用语音命令来更改语言。"
      },
    }
    return messages[key]?.[currentLanguage] || messages[key]?.["en-US"] || key
  }

  // Enhanced voice command handling
  const handleVoiceCommand = async (command: string) => {
    setLastCommand(command)
    const lowerCommand = command.toLowerCase()

    // Navigation commands with smooth transitions
    if (lowerCommand.includes("help") || lowerCommand.includes("सहायता")) {
      setCurrentView("help")
      speak("Opening help center")
    } else if (lowerCommand.includes("home") || lowerCommand.includes("main")) {
      setCurrentView("main")
      speak("Returning to main dashboard")
    } else if (lowerCommand.includes("scan") || lowerCommand.includes("camera")) {
      setCurrentView("ocr")
      speak("Activating smart text scanner")
    } else if (lowerCommand.includes("note") || lowerCommand.includes("record")) {
      setCurrentView("notes")
      speak("Opening audio notes studio")
    } else if (lowerCommand.includes("pdf") || lowerCommand.includes("document")) {
      setCurrentView("pdf")
      speak("Opening PDF reader")
    } else if (lowerCommand.includes("settings")) {
      setCurrentView("settings")
      speak("Opening advanced settings")
    } else if (lowerCommand.includes("language")) {
      setCurrentView("language")
      speak("Opening language selection")
    } else if (lowerCommand.includes("dark mode")) {
      setIsDarkMode(!isDarkMode)
      speak(isDarkMode ? "Light mode activated" : "Dark mode activated")
    } else if (lowerCommand.includes("high contrast")) {
      toggleHighContrast()
    } else if (lowerCommand.includes("read this")) {
      readCurrentPage()
    } else {
      speak("Command not recognized. Try saying 'help' for available commands.")
    }
  }

  const toggleHighContrast = () => {
    setIsHighContrast(!isHighContrast)
    speak(isHighContrast ? "High contrast disabled" : "High contrast enabled")
  }

  const readCurrentPage = () => {
    const textContent = document.body.innerText
    speak(`Reading current page: ${textContent.substring(0, 200)}...`)
  }

  const generateSummary = (text: string): string => {
    const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 10)
    if (sentences.length <= 3) return text

    const firstSentence = sentences[0]?.trim()
    const longestSentence = sentences.reduce((a, b) => (a.length > b.length ? a : b))?.trim()
    const lastSentence = sentences[sentences.length - 1]?.trim()

    return (
      [firstSentence, longestSentence, lastSentence].filter((s, i, arr) => s && arr.indexOf(s) === i).join(". ") + "."
    )
  }

  const handleTextExtracted = (text: string) => {
    setExtractedText(text)
    const summary = generateSummary(text)
    setTextSummary(summary)
    console.log('Main page: About to speak "Text extracted successfully"')
    speak(`Text extracted successfully`)
  }

  // Enhanced keyboard navigation
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.altKey) return

      switch (e.key.toLowerCase()) {
        case "h":
          e.preventDefault()
          setCurrentView("help")
          speak("Help center")
          break
        case "c":
          e.preventDefault()
          setCurrentView("ocr")
          speak("Text scanner")
          break
        case "n":
          e.preventDefault()
          setCurrentView("notes")
          speak("Audio notes")
          break
        case "p":
          e.preventDefault()
          setCurrentView("pdf")
          speak("PDF reader")
          break
        case "s":
          e.preventDefault()
          setCurrentView("settings")
          speak("Settings")
          break
        case "l":
          e.preventDefault()
          setCurrentView("language")
          const t = getLocalizedMessage("languageDirections")
          speak(t)
          break
        case "m":
          e.preventDefault()
          setCurrentView("main")
          speak("Main dashboard")
          break
        case "t":
          e.preventDefault()
          toggleHighContrast()
          break
        case "d":
          e.preventDefault()
          setIsDarkMode(!isDarkMode)
          speak(isDarkMode ? "Light mode" : "Dark mode")
          break
        case " ":
          e.preventDefault()
          toggleVoiceListening()
          break
      }
    }

    document.addEventListener("keydown", handleKeyPress)
    return () => document.removeEventListener("keydown", handleKeyPress)
  }, [isSpeaking, isListening, isDarkMode])

  const toggleVoiceListening = () => {
    if (isListening) {
      stopListening()
      setIsListening(false)
      speak("Voice recognition stopped")
    } else {
      startListening(handleVoiceCommand)
      setIsListening(true)
      speak("Listening for commands")
    }
  }

  return (
    <div
      ref={containerRef}
      className={`min-h-screen relative overflow-hidden ${isHighContrast ? "high-contrast" : ""}`}
    >
      {/* GSAP Animations Component */}
      <GSAPAnimations containerRef={containerRef} />

      {/* Animated Background */}
      <AnimatedBackground isDarkMode={isDarkMode} isHighContrast={isHighContrast} />

      {/* Floating Elements */}
      <FloatingElements mousePosition={mousePosition} />

      {/* Skip to main content */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-primary text-primary-foreground px-6 py-3 rounded-xl z-50 font-semibold shadow-lg"
      >
        Skip to main content
      </a>

      {/* Vibrant Header */}
      <header className="gsap-header relative z-10 overflow-hidden" role="banner">
        <div className="absolute inset-0 gradient-bg-aurora opacity-80"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-white/30 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10"></div>

        {/* Vibrant animated elements in header */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="gsap-particle absolute w-2 h-2 bg-gradient-to-r from-primary to-secondary rounded-full animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${3 + Math.random() * 4}s`,
              }}
            />
          ))}
          {[...Array(8)].map((_, i) => (
            <div
              key={`sparkle-${i}`}
              className="absolute w-1 h-1 bg-accent rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
              }}
            />
          ))}
        </div>

        <div className="relative z-10 container mx-auto px-6 py-12">
          <div className="text-center">
            {/* Logo and Title */}
            <div className="gsap-hero-content flex items-center justify-center mb-8">
              <div className="relative">
                <div className="w-20 h-20 bg-gradient-to-br from-primary via-secondary to-accent backdrop-blur-sm rounded-3xl flex items-center justify-center mr-6 gsap-logo animate-scale-bounce shadow-2xl">
                  <span className="text-4xl">📚</span>
                </div>
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-r from-accent to-primary rounded-full animate-bounce-colorful"></div>
                <div className="absolute -bottom-1 -left-1 w-4 h-4 bg-gradient-to-r from-secondary to-accent rounded-full animate-pulse"></div>
              </div>
              <div className="text-left">
                <h1 className="gsap-title text-4xl lg:text-6xl font-black mb-2">
                  <span className="text-gray-900 dark:text-gray-100 drop-shadow-lg">
                    Smart Learning
                  </span>
                  <span className="block text-3xl lg:text-5xl text-blue-600 dark:text-blue-400 gsap-subtitle">
                    Assistant
                  </span>
                </h1>
                <p className="text-lg lg:text-xl font-medium gsap-tagline text-gray-700 dark:text-gray-300">
                   AI-Powered •  Voice-First •  Fully Accessible
                </p>
              </div>
            </div>

            {/* Status Badges */}
            <div className="gsap-badges flex flex-wrap items-center justify-center gap-3 mb-6">
              <Badge
                variant={isListening ? "default" : "secondary"}
                className={`px-4 py-2 text-base font-semibold ${
                  isListening ? "bg-gradient-to-r from-success to-primary text-white animate-pulse shadow-lg" : "bg-gradient-to-r from-primary/20 to-secondary/20 text-primary border-primary/30"
                }`}
              >
                {isListening ? "🎤 Listening..." : "⏸️ Ready"}
              </Badge>
              {isSpeaking && (
                <Badge variant="outline" className="px-4 py-2 text-base bg-gradient-to-r from-accent/20 to-primary/20 text-accent border-accent/30 animate-glow-pulse">
                  🔊 Speaking
                </Badge>
              )}
              {isHighContrast && (
                <Badge variant="outline" className="px-4 py-2 text-base bg-gradient-to-r from-warning/20 to-accent/20 text-warning border-warning/30">
                  🔆 High Contrast
                </Badge>
              )}
              <Badge variant="outline" className="px-4 py-2 text-base bg-gradient-to-r from-secondary/20 to-accent/20 text-secondary border-secondary/30">
                🌐 {SUPPORTED_LANGUAGES[currentLanguage].name}
              </Badge>
            </div>

            {/* Status Message */}
            <div className="gsap-status text-center">
              <p className="text-2xl lg:text-3xl font-bold mb-2 text-gray-900 dark:text-gray-100 drop-shadow-md" aria-live="polite">
                {appStatus}
              </p>
              <div className="flex items-center justify-center gap-2">
                <div
                  className={`w-3 h-3 rounded-full ${
                    voiceSupported 
                      ? "bg-success animate-pulse shadow-lg" 
                      : "bg-destructive"
                  }`}
                ></div>
                <span className="text-sm text-gray-700 dark:text-gray-300 font-medium">
                  {voiceSupported ? "Voice Recognition Active" : "Voice Recognition Unavailable"}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Vibrant Navigation */}
      <nav
        className="gsap-nav relative z-10 bg-white/80 dark:bg-slate-800/80 backdrop-blur-lg border-b border-primary/20 dark:border-primary/30 sticky top-0 shadow-lg"
        role="navigation"
      >
        <div className="container mx-auto px-6 py-4">
          <div className="flex flex-wrap items-center justify-center gap-3">
            {[
              { view: "main", icon: FileText, label: "Dashboard", key: "M" },
              { view: "ocr", icon: Camera, label: "Scanner", key: "C" },
              { view: "notes", icon: Mic, label: "Notes", key: "N" },
              { view: "pdf", icon: FileText, label: "PDF Reader", key: "P" },
              { view: "language", icon: Languages, label: "Languages", key: "L" },
              { view: "settings", icon: Settings, label: "Settings", key: "S" },
              { view: "help", icon: HelpCircle, label: "Help", key: "H" },
            ].map(({ view, icon: Icon, label, key }) => (
              <Button
                key={view}
                variant={currentView === view ? "default" : "ghost"}
                onClick={() => {
                  setCurrentView(view as any)
                  speak(`${label} section`)
                }}
                className={`nav-button ${currentView === view ? "nav-button-active" : ""}`}
                aria-pressed={currentView === view}
              >
                <Icon className="w-5 h-5 mr-2" />
                {label} ({key})
              </Button>
            ))}
          </div>
        </div>
      </nav>

      {/* Voice Control Panel */}
      <section className="gsap-voice-panel relative z-10 bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 backdrop-blur-sm border-b border-primary/20 dark:border-primary/30 shadow-lg">
        <div className="container mx-auto px-6 py-6">
          {/* Main Voice Button */}
          <div className="text-center mb-6">
            <Button
              onClick={toggleVoiceListening}
              className={`voice-control-main ${isListening ? "listening" : ""}`}
              aria-pressed={isListening}
            >
              <div className="flex items-center justify-center">
                {isListening ? (
                  <>
                    <MicOff className="w-8 h-8 mr-4" />
                    <span className="text-xl font-bold">🛑 Stop Listening</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-8 h-8 mr-4" />
                    <span className="text-xl font-bold">🎤 Start Listening</span>
                  </>
                )}
              </div>
              <div className="text-sm opacity-80 mt-1">Press Space or click here</div>
            </Button>

            {/* Voice Visualizer */}
            {isListening && <VoiceVisualizer isActive={isListening} />}
          </div>

          {/* Secondary Controls */}
          <div className="gsap-controls grid grid-cols-1 md:grid-cols-4 gap-4">
            <Button
              onClick={() => (isSpeaking ? stopSpeaking() : speak("Voice test successful!"))}
              variant="outline"
              className="control-button"
            >
              {isSpeaking ? <VolumeX className="w-5 h-5 mr-2" /> : <Volume2 className="w-5 h-5 mr-2" />}
              {isSpeaking ? "Stop" : "Test Voice"}
            </Button>

            <Button onClick={toggleHighContrast} variant="outline" className="control-button bg-transparent">
              <Contrast className="w-5 h-5 mr-2" />
              High Contrast (T)
            </Button>

            <Button onClick={() => setIsDarkMode(!isDarkMode)} variant="outline" className="control-button">
              {isDarkMode ? "☀️" : "🌙"} {isDarkMode ? "Light" : "Dark"} (D)
            </Button>

            <Button onClick={readCurrentPage} variant="outline" className="control-button bg-transparent">
              <FileText className="w-5 h-5 mr-2" />
              Read Page
            </Button>
          </div>

          {/* Last Command Display */}
          {lastCommand && (
            <div className="gsap-command mt-4 p-4 bg-white/60 dark:bg-slate-700/60 backdrop-blur-sm rounded-xl border border-slate-200/50 dark:border-slate-600/50">
              <div className="text-center">
                <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Last Command:</span>
                <span className="ml-2 font-bold text-slate-800 dark:text-slate-200">{lastCommand}</span>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Main Content */}
      <main id="main-content" ref={mainRef} className="relative z-10 container mx-auto px-6 py-8" role="main">
        {currentView === "main" && (
          <div className="space-y-12">
            {/* Hero Section */}
            <div ref={heroRef} className="gsap-hero text-center py-12">
              <h2 className="text-4xl lg:text-6xl font-black mb-6">
                <span className="text-gray-900 dark:text-gray-100 drop-shadow-lg">
                  Welcome to the Future
                </span>
                <br />
                <span className="text-blue-600 dark:text-blue-400">
                  of Accessible Learning
                </span>
              </h2>
              <p className="text-xl lg:text-2xl mb-8 max-w-4xl mx-auto text-gray-700 dark:text-gray-300">
                Experience revolutionary AI-powered education with voice commands, smart OCR, and multilingual support.
                Built for everyone, optimized for accessibility.
              </p>

              {/* Stats Counter */}
              
            </div>

            {/* Feature Showcase */}
            <FeatureShowcase onFeatureSelect={setCurrentView} />

            {/* Quick Actions Grid */}
            <div className="gsap-features grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[
                {
                  title: "Smart Text Scanner",
                  description: "Advanced OCR with AI-powered text recognition and instant voice output",
                  icon: Camera,
                  color: "from-primary/20 to-accent/20 dark:from-primary/30 dark:to-accent/30",
                  action: () => setCurrentView("ocr"),
                  features: ["Multi-language OCR", "Text Summarization", "Voice Output", "Image Enhancement"],
                },
                {
                  title: "Audio Notes Studio",
                  description: "Professional-grade voice recording with smart organization",
                  icon: Mic,
                  color: "from-secondary/20 to-primary/20 dark:from-secondary/30 dark:to-primary/30",
                  action: () => setCurrentView("notes"),
                  features: ["HD Audio Recording", "Smart Transcription", "Voice Commands", "Cloud Sync"],
                },
                {
                  title: "PDF Text Reader",
                  description: "Upload and read PDF documents with AI-powered text extraction",
                  icon: FileText,
                  color: "from-accent/20 to-secondary/20 dark:from-accent/30 dark:to-secondary/30",
                  action: () => setCurrentView("pdf"),
                  features: ["PDF Upload", "Text Extraction", "Voice Reading", "Page Navigation"],
                },
                {
                  title: "Global Languages",
                  description: "Support for 15+ languages with native voice synthesis",
                  icon: Globe,
                  color: "from-primary/20 to-secondary/20 dark:from-primary/30 dark:to-secondary/30",
                  action: () => setCurrentView("language"),
                  features: ["Indian Languages", "Voice Commands", "Real-time Translation", "Cultural Context"],
                },
              ].map((feature, index) => (
                <Card key={index} className="feature-card-enhanced group cursor-pointer" onClick={feature.action}>
                  <CardHeader className="pb-4">
                    <div
                      className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}
                    >
                      <feature.icon className="w-8 h-8 text-primary animate-rainbow" />
                    </div>
                    <CardTitle className="text-xl font-bold text-foreground">
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="mb-4 text-muted-foreground">{feature.description}</p>
                    <div className="space-y-2">
                      {feature.features.map((feat, i) => (
                        <div key={i} className="flex items-center text-sm">
                          <Star className="w-4 h-4 text-accent mr-2" />
                          <span className="text-muted-foreground">{feat}</span>
                        </div>
                      ))}
                    </div>
                    <Button className="w-full mt-4 bg-gradient-to-r from-primary to-secondary hover:from-secondary hover:to-accent text-white shadow-lg hover:shadow-xl transition-all duration-300">
                      Explore <ArrowRight className="w-4 h-4 ml-2 animate-bounce-gentle" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Voice Commands Preview */}
            <Card className="gsap-commands command-showcase">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-center text-foreground">
                  Voice Commands Made Simple
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  {[
                    { category: "Navigation", commands: ["Go to scanner", "Open notes", "Open PDF reader", "Show help"] },
                    { category: "Actions", commands: ["Read this page", "Start recording", "Scan text", "Upload PDF"] },
                    { category: "Controls", commands: ["High contrast", "Dark mode", "Change language"] },
                  ].map((group, index) => (
                    <div
                      key={index}
                      className="text-center p-6 bg-muted/50 rounded-xl border border-border shadow-lg hover:shadow-xl transition-all duration-300"
                    >
                      <h3 className="font-bold text-lg mb-4 text-foreground">{group.category}</h3>
                      <div className="space-y-2">
                        {group.commands.map((cmd, i) => (
                          <Badge
                            key={i}
                            variant="outline"
                            className="block w-full py-2 bg-muted text-foreground border-border hover:bg-muted/80 transition-all duration-300"
                          >
                            "{cmd}"
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {currentView === "ocr" && (
          <div className="gsap-page-content">
            <OCRCamera onTextExtracted={handleTextExtracted} onError={(error) => speak(`Scanner error: ${error}`)} />
          </div>
        )}

        {currentView === "notes" && (
          <div className="gsap-page-content">
            <AudioNoteRecorder
              notes={notes}
              isRecording={isRecording}
              onStartRecording={startRecording}
              onStopRecording={stopRecording}
              onPlayNote={playNote}
              onDeleteNote={deleteNote}
              onUpdateNoteTitle={updateNoteTitle}
              isTranscribing={isTranscribing}
              currentTranscript={currentTranscript}
              transcript={transcript}
              interimTranscript={interimTranscript}
            />
          </div>
        )}

        {currentView === "pdf" && (
          <div className="gsap-page-content space-y-6">
            <PDFManager
              storedPDFs={storedPDFs}
              currentPDF={currentPDF}
              onLoadPDF={loadPDF}
              onDeletePDF={deletePDF}
              onUpdatePDF={updatePDF}
              onClearAll={clearAllPDFs}
            />
            <PDFReader
              onTextExtracted={handleTextExtracted}
              onError={(error) => speak(`PDF error: ${error}`)}
            />
          </div>
        )}

        {currentView === "language" && (
          <div className="gsap-page-content">
            <LanguageSelector
              currentLanguage={currentLanguage}
              supportedLanguages={SUPPORTED_LANGUAGES}
              onLanguageChange={(lang) => {
                setCurrentLanguage(lang)
              }}
              onSpeak={speak}
            />
          </div>
        )}

        {currentView === "settings" && (
          <div className="gsap-page-content">
            <SettingsPanel
              ttsSettings={ttsSettings}
              isHighContrast={isHighContrast}
              onSettingsChange={() => speak("Settings updated")}
              onHighContrastToggle={toggleHighContrast}
            />
          </div>
        )}

        {currentView === "help" && (
          <div className="gsap-page-content">
            <HelpPanel
              onCommandSpoken={speak}
              supportedLanguages={SUPPORTED_LANGUAGES}
              currentLanguage={currentLanguage}
            />
          </div>
        )}
      </main>

      {/* Voice Command Processor */}
      <VoiceCommandProcessor
        isListening={isListening}
        onCommand={handleVoiceCommand}
        onStatusChange={setAppStatus}
        currentLanguage={currentLanguage}
      />
    </div>
  )
}
