"use client"

import { useState, useCallback, useRef } from "react"

interface TranscriptionResult {
  transcript: string
  confidence: number
  isFinal: boolean
}

export function useTranscription() {
  const [isTranscribing, setIsTranscribing] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [interimTranscript, setInterimTranscript] = useState("")
  const [confidence, setConfidence] = useState(0)
  const [isSupported, setIsSupported] = useState(false)
  
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const onResultRef = useRef<((result: TranscriptionResult) => void) | null>(null)

  const initializeRecognition = useCallback(() => {
    if (typeof window === "undefined") return false

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SpeechRecognition) return false

    const recognition = new SpeechRecognition()
    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = "en-US"
    recognition.maxAlternatives = 1

    recognition.onstart = () => {
      setIsTranscribing(true)
      setTranscript("")
      setInterimTranscript("")
    }

    recognition.onresult = (event) => {
      let finalTranscript = ""
      let interimTranscript = ""

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i]
        const transcript = result[0].transcript
        
        if (result.isFinal) {
          finalTranscript += transcript + " "
          setConfidence(result[0].confidence || 0)
        } else {
          interimTranscript += transcript
        }
      }

      if (finalTranscript) {
        setTranscript(prev => prev + finalTranscript)
        setInterimTranscript("")
      } else {
        setInterimTranscript(interimTranscript)
      }

      // Call the callback with the result
      if (onResultRef.current) {
        onResultRef.current({
          transcript: finalTranscript || interimTranscript,
          confidence: event.results[event.results.length - 1][0].confidence || 0,
          isFinal: event.results[event.results.length - 1].isFinal
        })
      }
    }

    recognition.onerror = (event) => {
      console.error("Speech recognition error:", event.error)
      setIsTranscribing(false)
    }

    recognition.onend = () => {
      setIsTranscribing(false)
    }

    recognitionRef.current = recognition
    setIsSupported(true)
    return true
  }, [])

  const startTranscription = useCallback((onResult?: (result: TranscriptionResult) => void) => {
    if (!recognitionRef.current) {
      if (!initializeRecognition()) {
        console.error("Speech recognition not supported")
        return false
      }
    }

    if (isTranscribing) return false

    onResultRef.current = onResult || null
    
    try {
      recognitionRef.current.start()
      console.log("Transcription started successfully")
      return true
    } catch (error) {
      console.error("Failed to start transcription:", error)
      // Try to restart recognition if it fails
      if (error.name === 'InvalidStateError') {
        console.log("Attempting to restart recognition...")
        setTimeout(() => {
          try {
            recognitionRef.current?.start()
          } catch (retryError) {
            console.error("Failed to restart transcription:", retryError)
          }
        }, 100)
      }
      return false
    }
  }, [isTranscribing, initializeRecognition])

  const stopTranscription = useCallback(() => {
    if (recognitionRef.current && isTranscribing) {
      recognitionRef.current.stop()
    }
  }, [isTranscribing])

  const resetTranscript = useCallback(() => {
    setTranscript("")
    setInterimTranscript("")
    setConfidence(0)
  }, [])

  const getFullTranscript = useCallback(() => {
    return transcript + (interimTranscript ? ` ${interimTranscript}` : "")
  }, [transcript, interimTranscript])

  return {
    isTranscribing,
    transcript,
    interimTranscript,
    confidence,
    isSupported,
    startTranscription,
    stopTranscription,
    resetTranscript,
    getFullTranscript,
  }
}
