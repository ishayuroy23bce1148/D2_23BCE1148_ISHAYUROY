"use client"

import { useState, useEffect, useCallback, useRef } from "react"

export function useVoiceRecognition() {
  const [isListening, setIsListening] = useState(false)
  const [isSupported, setIsSupported] = useState(false)
  const [transcript, setTranscript] = useState("")

  const recognitionRef = useRef<any | null>(null)
  const callbackRef = useRef<((command: string) => void) | null>(null)

  useEffect(() => {
    if (typeof window !== "undefined") {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition

      if (SpeechRecognition) {
        setIsSupported(true)

        const recognition = new SpeechRecognition()
        recognition.continuous = false
        recognition.interimResults = false
        recognition.lang = "en-US"
        recognition.maxAlternatives = 1

        recognition.onstart = () => {
          setIsListening(true)
        }

        recognition.onresult = (event) => {
          const result = event.results[0][0].transcript
          setTranscript(result)

          if (callbackRef.current) {
            callbackRef.current(result)
          }
        }

        recognition.onend = () => {
          setIsListening(false)
        }

        recognition.onerror = (event) => {
          console.error("Speech recognition error:", event.error)
          setIsListening(false)

          if (callbackRef.current) {
            callbackRef.current(`Error: ${event.error}`)
          }
        }

        recognitionRef.current = recognition
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort()
      }
    }
  }, [])

  const startListening = useCallback(
    (callback?: (command: string) => void) => {
      if (!isSupported || !recognitionRef.current) return

      callbackRef.current = callback || null

      try {
        recognitionRef.current.start()
      } catch (error) {
        console.error("Failed to start speech recognition:", error)
      }
    },
    [isSupported],
  )

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop()
    }
  }, [isListening])

  return {
    startListening,
    stopListening,
    isListening,
    isSupported,
    transcript,
  }
}
