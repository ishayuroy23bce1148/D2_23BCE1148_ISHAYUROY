"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { api, APIError } from "@/lib/api"
import { useTranscription } from "./use-transcription"

interface AudioNote {
  id: string
  title: string
  blob: Blob
  duration: number
  createdAt: Date
  tags: string[]
  transcript?: string
  filename?: string
}

export function useAudioNotes() {
  const [notes, setNotes] = useState<AudioNote[]>([])
  const [isRecording, setIsRecording] = useState(false)
  const [isSupported, setIsSupported] = useState(false)
  const [currentTranscript, setCurrentTranscript] = useState("")

  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const streamRef = useRef<MediaStream | null>(null)
  
  const {
    isTranscribing,
    transcript,
    interimTranscript,
    startTranscription,
    stopTranscription,
    resetTranscript,
    getFullTranscript,
  } = useTranscription()

  useEffect(() => {
    if (typeof window !== "undefined" && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      setIsSupported(true)
      loadNotes()
    }
  }, [])

  const loadNotes = async () => {
    try {
      const savedNotes = localStorage.getItem("audio-notes")
      if (savedNotes) {
        const parsedNotes = JSON.parse(savedNotes)
        setNotes(
          parsedNotes.map((note: any) => ({
            ...note,
            createdAt: new Date(note.createdAt),
          })),
        )
      }
    } catch (error) {
      console.error("Failed to load notes:", error)
    }
  }

  const saveNotes = (updatedNotes: AudioNote[]) => {
    try {
      localStorage.setItem("audio-notes", JSON.stringify(updatedNotes))
    } catch (error) {
      console.error("Failed to save notes:", error)
    }
  }

  const startRecording = useCallback(async () => {
    if (!isSupported || isRecording) return

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100,
        },
      })

      streamRef.current = stream
      chunksRef.current = []
      resetTranscript() // Reset transcript for new recording

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: "audio/webm;codecs=opus",
      })

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data)
        }
      }

      mediaRecorder.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm;codecs=opus" })
        // Get the final transcript from the transcription hook
        const finalTranscript = getFullTranscript()
        console.log("Final transcript captured:", finalTranscript)
        
        const newNote: AudioNote = {
          id: Date.now().toString(),
          title: `Note ${notes.length + 1}`,
          blob,
          duration: 0, // Will be calculated when playing
          createdAt: new Date(),
          tags: [],
          transcript: finalTranscript, // Include the real-time transcript
        }

        // Try to save to backend
        try {
          const result = await api.saveAudioNote(blob as File, {
            title: newNote.title,
            tags: newNote.tags,
            transcript: finalTranscript,
          })
          
          // Update note with backend response
          newNote.id = result.note.id
          newNote.filename = result.note.filename
          newNote.transcript = result.note.transcript || finalTranscript
        } catch (error) {
          console.warn("Failed to save to backend, using local storage:", error)
        }

        const updatedNotes = [...notes, newNote]
        setNotes(updatedNotes)
        saveNotes(updatedNotes)

        // Clean up
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((track) => track.stop())
          streamRef.current = null
        }
      }

      mediaRecorderRef.current = mediaRecorder
      mediaRecorder.start()
      setIsRecording(true)
      
      // Start real-time transcription
      startTranscription((result) => {
        if (result.isFinal) {
          setCurrentTranscript(getFullTranscript())
        }
      })
    } catch (error) {
      console.error("Failed to start recording:", error)
    }
  }, [isSupported, isRecording, notes, resetTranscript, getFullTranscript, startTranscription])

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      stopTranscription() // Stop transcription when recording stops
      setIsRecording(false)
    }
  }, [isRecording, stopTranscription])

  const playNote = useCallback((note: AudioNote) => {
    const audio = new Audio(URL.createObjectURL(note.blob))
    audio.play().catch((error) => {
      console.error("Failed to play note:", error)
    })
  }, [])

  const deleteNote = useCallback(
    (noteId: string) => {
      const updatedNotes = notes.filter((note) => note.id !== noteId)
      setNotes(updatedNotes)
      saveNotes(updatedNotes)
    },
    [notes],
  )

  const updateNoteTitle = useCallback(
    (noteId: string, title: string) => {
      const updatedNotes = notes.map((note) => (note.id === noteId ? { ...note, title } : note))
      setNotes(updatedNotes)
      saveNotes(updatedNotes)
    },
    [notes],
  )

  return {
    notes,
    isRecording,
    isSupported,
    startRecording,
    stopRecording,
    playNote,
    deleteNote,
    updateNoteTitle,
    // Transcription data
    isTranscribing,
    currentTranscript,
    transcript,
    interimTranscript,
  }
}
