"use client"

import { useState, useEffect, useCallback, useRef } from "react"

interface TTSSettings {
  rate: number
  pitch: number
  volume: number
  voice: string
}

export function useTTS() {
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isSupported, setIsSupported] = useState(false)
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([])
  const [userInteracted, setUserInteracted] = useState(false)
  const [settings, setSettings] = useState<TTSSettings>({
    rate: 1,
    pitch: 1,
    volume: 1,
    voice: "",
  })

  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null)

  useEffect(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      setIsSupported(true)
      console.log('TTS: Speech synthesis is supported')

      // Load voices
      const loadVoices = () => {
        const availableVoices = speechSynthesis.getVoices()
        console.log('TTS: Available voices:', availableVoices.length)
        setVoices(availableVoices)

        // Set default voice (prefer English)
        const englishVoice = availableVoices.find((voice) => voice.lang.startsWith("en"))
        if (englishVoice && !settings.voice) {
          console.log('TTS: Setting default English voice:', englishVoice.name)
          setSettings((prev) => ({ ...prev, voice: englishVoice.name }))
        }
      }

      // Load voices immediately and on change
      loadVoices()
      speechSynthesis.addEventListener("voiceschanged", loadVoices)

      // Test speech synthesis availability
      const testUtterance = new SpeechSynthesisUtterance('')
      console.log('TTS: Test utterance created successfully')

      return () => {
        speechSynthesis.removeEventListener("voiceschanged", loadVoices)
      }
    } else {
      console.log('TTS: Speech synthesis not supported')
    }
  }, [settings.voice])

  const speak = useCallback(
    (text: string, options?: Partial<TTSSettings>) => {
      console.log('TTS Speak called with:', { text: text.substring(0, 100) + '...', isSupported, textLength: text.length, userInteracted })
      
      if (!isSupported) {
        console.log('TTS not supported')
        return
      }
      
      if (!text.trim()) {
        console.log('TTS: No text to speak')
        return
      }

      // Mark that user has interacted
      setUserInteracted(true)

      // Stop any current speech
      speechSynthesis.cancel()

      const utterance = new SpeechSynthesisUtterance(text)
      const currentSettings = { ...settings, ...options }

      utterance.rate = currentSettings.rate
      utterance.pitch = currentSettings.pitch
      utterance.volume = currentSettings.volume

      // Set voice
      if (currentSettings.voice) {
        const selectedVoice = voices.find((voice) => voice.name === currentSettings.voice)
        if (selectedVoice) {
          utterance.voice = selectedVoice
        }
      }

      utterance.onstart = () => {
        console.log('TTS: Speech started')
        setIsSpeaking(true)
      }
      utterance.onend = () => {
        console.log('TTS: Speech ended')
        setIsSpeaking(false)
      }
      utterance.onerror = (event) => {
        console.error('TTS Error:', event)
        setIsSpeaking(false)
      }

      utteranceRef.current = utterance
      console.log('TTS: Starting speech synthesis')
      speechSynthesis.speak(utterance)
    },
    [isSupported, settings, voices, userInteracted],
  )

  const stop = useCallback(() => {
    if (isSupported) {
      speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }, [isSupported])

  const pause = useCallback(() => {
    if (isSupported && isSpeaking) {
      speechSynthesis.pause()
    }
  }, [isSupported, isSpeaking])

  const resume = useCallback(() => {
    if (isSupported) {
      speechSynthesis.resume()
    }
  }, [isSupported])

  const updateSettings = useCallback((newSettings: Partial<TTSSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }))
  }, [])

  return {
    speak,
    stop,
    pause,
    resume,
    isSpeaking,
    isSupported,
    voices,
    settings,
    updateSettings,
  }
}
