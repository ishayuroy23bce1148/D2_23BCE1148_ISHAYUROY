"use client"

import { useState, useEffect, useCallback } from 'react'

export interface StoredPDF {
  id: string
  name: string
  originalName: string
  extractedText: string
  pages: number
  title?: string
  uploadedAt: string
  lastAccessed: string
  fileSize?: number
  pageTexts: string[]
  summary?: string
}

export interface PDFStorageHook {
  storedPDFs: StoredPDF[]
  currentPDF: StoredPDF | null
  isLoading: boolean
  savePDF: (pdfData: Omit<StoredPDF, 'id' | 'uploadedAt' | 'lastAccessed'>) => string
  loadPDF: (id: string) => StoredPDF | null
  deletePDF: (id: string) => void
  updatePDF: (id: string, updates: Partial<StoredPDF>) => void
  clearAllPDFs: () => void
  setCurrentPDF: (pdf: StoredPDF | null) => void
}

const STORAGE_KEY = 'smart-learning-pdfs'

export function usePDFStorage(): PDFStorageHook {
  const [storedPDFs, setStoredPDFs] = useState<StoredPDF[]>([])
  const [currentPDF, setCurrentPDF] = useState<StoredPDF | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Load PDFs from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      if (stored) {
        const parsed = JSON.parse(stored)
        setStoredPDFs(parsed)
        
        // Load the most recently accessed PDF
        if (parsed.length > 0) {
          const mostRecent = parsed.sort((a: StoredPDF, b: StoredPDF) => 
            new Date(b.lastAccessed).getTime() - new Date(a.lastAccessed).getTime()
          )[0]
          setCurrentPDF(mostRecent)
        }
      }
    } catch (error) {
      console.error('Error loading PDFs from storage:', error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  // Save PDFs to localStorage whenever storedPDFs changes
  useEffect(() => {
    if (!isLoading) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(storedPDFs))
      } catch (error) {
        console.error('Error saving PDFs to storage:', error)
      }
    }
  }, [storedPDFs, isLoading])

  const savePDF = useCallback((pdfData: Omit<StoredPDF, 'id' | 'uploadedAt' | 'lastAccessed'>): string => {
    const id = `pdf_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const now = new Date().toISOString()
    
    const newPDF: StoredPDF = {
      ...pdfData,
      id,
      uploadedAt: now,
      lastAccessed: now
    }

    setStoredPDFs(prev => {
      // Remove any existing PDF with the same name to avoid duplicates
      const filtered = prev.filter(pdf => pdf.name !== newPDF.name)
      return [...filtered, newPDF]
    })

    setCurrentPDF(newPDF)
    return id
  }, [])

  const loadPDF = useCallback((id: string): StoredPDF | null => {
    const pdf = storedPDFs.find(p => p.id === id)
    if (pdf) {
      // Update last accessed time
      const updatedPDF = { ...pdf, lastAccessed: new Date().toISOString() }
      setStoredPDFs(prev => 
        prev.map(p => p.id === id ? updatedPDF : p)
      )
      setCurrentPDF(updatedPDF)
      return updatedPDF
    }
    return null
  }, [storedPDFs])

  const deletePDF = useCallback((id: string) => {
    setStoredPDFs(prev => prev.filter(pdf => pdf.id !== id))
    if (currentPDF?.id === id) {
      setCurrentPDF(null)
    }
  }, [currentPDF])

  const updatePDF = useCallback((id: string, updates: Partial<StoredPDF>) => {
    setStoredPDFs(prev => 
      prev.map(pdf => pdf.id === id ? { ...pdf, ...updates } : pdf)
    )
    if (currentPDF?.id === id) {
      setCurrentPDF(prev => prev ? { ...prev, ...updates } : null)
    }
  }, [currentPDF])

  const clearAllPDFs = useCallback(() => {
    setStoredPDFs([])
    setCurrentPDF(null)
  }, [])

  return {
    storedPDFs,
    currentPDF,
    isLoading,
    savePDF,
    loadPDF,
    deletePDF,
    updatePDF,
    clearAllPDFs,
    setCurrentPDF
  }
}




